import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Player as PlayerType, LootCrate as LootCrateType } from '../types';
import { GAME_DURATION_SECONDS, PLAYER_SPAWN_INTERVAL_MS, MIN_PLAYER_SIZE, MAX_PLAYER_SIZE, MAPS, LOOT_SPAWN_INTERVAL_MS, LOOT_CRATE_SIZE } from '../constants';
import Hud from './Hud';
import { Player, LootCrate } from './Target';
import { CrosshairIcon } from './icons';

interface GameScreenProps {
  onGameOver: (finalScore: number) => void;
  playerName: string;
  mapId: number;
}

const GameScreen: React.FC<GameScreenProps> = ({ onGameOver, playerName, mapId }) => {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION_SECONDS);
  const [players, setPlayers] = useState<PlayerType[]>([]);
  const [lootCrates, setLootCrates] = useState<LootCrateType[]>([]);

  const gameAreaRef = useRef<HTMLDivElement>(null);
  const crosshairRef = useRef<SVGSVGElement>(null);
  const animationFrameId = useRef<number | null>(null);
  const scoreRef = useRef(score);
  scoreRef.current = score;

  const selectedMap = MAPS.find(m => m.id === mapId) || MAPS[0];

  const handlePlayerHit = useCallback((id: number) => {
    setPlayers((prev) => prev.filter((p) => p.id !== id));
    setScore((prev) => prev + 100);
  }, [setPlayers, setScore]);
  
  const handleLootHit = useCallback((id: number, type: 'score' | 'time') => {
    setLootCrates((prev) => prev.filter((l) => l.id !== id));
    if (type === 'score') {
      setScore((prev) => prev + 500);
    } else if (type === 'time') {
      setTimeLeft((prev) => prev + 5);
    }
  }, [setLootCrates, setScore, setTimeLeft]);

  const spawnPlayer = useCallback(() => {
    if (!gameAreaRef.current) return;
    const { width, height } = gameAreaRef.current.getBoundingClientRect();
    const size = Math.random() * (MAX_PLAYER_SIZE - MIN_PLAYER_SIZE) + MIN_PLAYER_SIZE;
    
    const newPlayer: PlayerType = {
      id: Date.now(),
      x: Math.random() * (width - size),
      y: Math.random() * (height - size),
      size,
      vx: (Math.random() - 0.5) * 2,
      vy: (Math.random() - 0.5) * 2,
    };
    setPlayers((prev) => [...prev, newPlayer]);
  }, [setPlayers]);

  const spawnLoot = useCallback(() => {
    if (!gameAreaRef.current) return;
    const { width, height } = gameAreaRef.current.getBoundingClientRect();
    const size = LOOT_CRATE_SIZE;
    
    const newLoot: LootCrateType = {
      id: Date.now(),
      x: Math.random() * (width - size),
      y: Math.random() * (height - size),
      size,
      type: Math.random() > 0.5 ? 'score' : 'time',
    };
    setLootCrates((prev) => [...prev, newLoot]);
  }, [setLootCrates]);
  
  useEffect(() => {
    const gameTimer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          clearInterval(gameTimer);
          onGameOver(scoreRef.current);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    const playerSpawner = setInterval(spawnPlayer, PLAYER_SPAWN_INTERVAL_MS);
    const lootSpawner = setInterval(spawnLoot, LOOT_SPAWN_INTERVAL_MS);

    const gameArea = gameAreaRef.current;
    const handleMouseMove = (e: MouseEvent) => {
      if (crosshairRef.current) {
        crosshairRef.current.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
      }
    };
    gameArea?.addEventListener('mousemove', handleMouseMove);

    const gameLoop = () => {
        if (!gameAreaRef.current) return;
        const { width, height } = gameAreaRef.current.getBoundingClientRect();
        
        setPlayers(prevPlayers => prevPlayers.map(p => {
            let nextX = p.x + p.vx;
            let nextY = p.y + p.vy;
            let { vx, vy } = p;

            if (nextX <= 0 || nextX + p.size >= width) vx = -vx;
            if (nextY <= 0 || nextY + p.size >= height) vy = -vy;

            return { ...p, x: nextX, y: nextY, vx, vy };
        }));
        animationFrameId.current = requestAnimationFrame(gameLoop);
    };
    animationFrameId.current = requestAnimationFrame(gameLoop);

    return () => {
      clearInterval(gameTimer);
      clearInterval(playerSpawner);
      clearInterval(lootSpawner);
      gameArea?.removeEventListener('mousemove', handleMouseMove);
      if(animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [onGameOver, spawnPlayer, spawnLoot, setPlayers, setTimeLeft]);


  return (
    <div className="w-full h-full flex flex-col">
      <Hud score={score} timeLeft={timeLeft} playerName={playerName} />
      <div 
        ref={gameAreaRef} 
        className="flex-grow w-full relative overflow-hidden cursor-none group"
      >
        <CrosshairIcon ref={crosshairRef} className="pointer-events-none fixed top-0 left-0 w-8 h-8 text-cyan-400 z-50 opacity-0 group-hover:opacity-100 transition-opacity -translate-x-1/2 -translate-y-1/2" />
        
        {/* Render Obstacles */}
        {selectedMap.obstacles.map((obs, i) => (
          <div
            key={i}
            className="absolute bg-slate-800/50 border-2 border-slate-700 rounded-md"
            style={{
              left: `${obs.x}%`,
              top: `${obs.y}%`,
              width: `${obs.width}%`,
              height: `${obs.height}%`,
            }}
          ></div>
        ))}

        {players.map((p) => (
          <Player key={p.id} player={p} onHit={handlePlayerHit} />
        ))}
        {lootCrates.map((l) => (
          <LootCrate key={l.id} loot={l} onHit={handleLootHit} />
        ))}
      </div>
    </div>
  );
};

export default GameScreen;