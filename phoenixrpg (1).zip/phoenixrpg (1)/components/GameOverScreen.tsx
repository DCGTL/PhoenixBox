import React from 'react';

interface GameOverScreenProps {
  score: number;
  playerName: string;
  onRestart: () => void;
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ score, playerName, onRestart }) => {
  return (
    <div className="flex flex-col items-center text-center p-8 bg-gray-800/30 backdrop-blur-xl rounded-2xl shadow-2xl shadow-red-500/10 border border-gray-700/50 animate-fadeIn">
      <h2 className="text-2xl font-bold text-slate-300 tracking-wider">İyi savaştın, {playerName}</h2>
      <h1 className="text-5xl font-bold text-red-500 tracking-widest uppercase mt-2">Game Over</h1>
      <p className="mt-4 text-2xl text-slate-300">Nihai Puanın:</p>
      <p className="text-8xl font-bold text-cyan-400 my-4">{score}</p>
      <button
        onClick={onRestart}
        className="mt-8 px-10 py-4 bg-cyan-500 text-slate-900 font-bold text-xl uppercase tracking-wider rounded-lg shadow-lg shadow-cyan-500/30 transform hover:scale-105 hover:bg-cyan-400 transition-all duration-300"
      >
        Redeploy
      </button>
    </div>
  );
};

export default GameOverScreen;