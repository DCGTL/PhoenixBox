import React, { useState } from 'react';
import { Player as PlayerType, LootCrate as LootCrateType } from '../types';
import { BoxIcon } from './icons';

// Note: This file now handles both Player (enemy bots) and LootCrates.
// The filename remains Target.tsx due to project constraints.

interface PlayerProps {
  player: PlayerType;
  onHit: (id: number) => void;
}

export const Player: React.FC<PlayerProps> = ({ player, onHit }) => {
  const [isHit, setIsHit] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsHit(true);
    // Add a small delay for the hit animation to play
    setTimeout(() => onHit(player.id), 150);
  };

  const transitionClasses = 'transition-all duration-150 ease-out';
  const hitClasses = isHit ? 'scale-0 opacity-0 rotate-90' : 'scale-100 opacity-100 rotate-0';

  return (
    <div
      onClick={handleClick}
      className={`absolute flex items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-orange-600 shadow-lg shadow-red-500/50 transform ${transitionClasses} ${hitClasses} cursor-none`}
      style={{
        left: `${player.x}px`,
        top: `${player.y}px`,
        width: `${player.size}px`,
        height: `${player.size}px`,
        transition: 'left 0.1s linear, top 0.1s linear', // For smooth movement
      }}
    >
      <div className="w-3/4 h-3/4 rounded-full bg-slate-900/50 ring-2 ring-red-300"></div>
      <div className="absolute w-1/4 h-1/4 rounded-full bg-orange-400"></div>
    </div>
  );
};

interface LootCrateProps {
  loot: LootCrateType;
  onHit: (id: number, type: 'score' | 'time') => void;
}

export const LootCrate: React.FC<LootCrateProps> = ({ loot, onHit }) => {
    const [isHit, setIsHit] = useState(false);

    const handleClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      setIsHit(true);
      setTimeout(() => onHit(loot.id, loot.type), 150);
    };
  
    const transitionClasses = 'transition-all duration-150 ease-in-out';
    const hitClasses = isHit ? 'scale-0 opacity-0 -rotate-180' : 'scale-100 opacity-100 rotate-0';
    const colorClass = loot.type === 'score' ? 'text-yellow-400 shadow-yellow-400/50' : 'text-purple-400 shadow-purple-400/50';

    return (
        <div
            onClick={handleClick}
            className={`absolute flex items-center justify-center transform ${transitionClasses} ${hitClasses} cursor-none animate-pulse`}
            style={{
                left: `${loot.x}px`,
                top: `${loot.y}px`,
                width: `${loot.size}px`,
                height: `${loot.size}px`,
            }}
        >
           <BoxIcon className={`w-full h-full drop-shadow-lg ${colorClass}`} />
        </div>
    )
}

// Default export for backward compatibility if something still imports Target from this file.
// We are primarily using named exports Player and LootCrate now.
const DefaultTarget: React.FC<PlayerProps> = (props) => <Player {...props} />;
export default DefaultTarget;