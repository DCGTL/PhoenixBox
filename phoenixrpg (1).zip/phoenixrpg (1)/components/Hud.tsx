import React from 'react';
import { ClockIcon, StarIcon } from './icons';

interface HudProps {
  score: number;
  timeLeft: number;
  playerName: string;
}

const Hud: React.FC<HudProps> = ({ score, timeLeft, playerName }) => {
  return (
    <div className="w-full p-4 bg-black/20 backdrop-blur-md border-b border-slate-700 z-20">
      <div className="max-w-5xl mx-auto flex justify-between items-center text-2xl font-bold">
        <div className="flex items-center space-x-4">
          <span className="text-slate-200">{playerName}</span>
          <div className="flex items-center space-x-2">
            <StarIcon className="w-8 h-8 text-yellow-400" />
            <span className="text-cyan-400 w-24 text-left">{score}</span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <ClockIcon className="w-8 h-8 text-red-500" />
          <span className="text-slate-200">Time:</span>
          <span className="text-cyan-400 w-16 text-left">{timeLeft}</span>
        </div>
      </div>
    </div>
  );
};

export default Hud;