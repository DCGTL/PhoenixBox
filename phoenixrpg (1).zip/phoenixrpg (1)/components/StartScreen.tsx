import React, { useState, useMemo } from 'react';
import { ScopeIcon } from './icons';
import { MAPS } from '../constants';

interface StartScreenProps {
  onStart: (playerName: string, mapId: number) => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
  const [playerName, setPlayerName] = useState('');
  const [selectedMapId, setSelectedMapId] = useState(MAPS[0].id);

  const isDeployDisabled = useMemo(() => playerName.trim().length < 3, [playerName]);

  return (
    <div className="flex flex-col items-center text-center p-8 bg-gray-800/30 backdrop-blur-xl rounded-2xl shadow-2xl shadow-cyan-500/10 border border-gray-700/50 animate-fadeIn w-[500px]">
      <ScopeIcon className="w-24 h-24 text-cyan-400 mb-4" />
      <h1 className="text-5xl font-bold text-cyan-400 tracking-widest uppercase">PhoenixRPG</h1>
      <p className="mt-4 text-lg text-slate-300 max-w-md">
        Arenaya girin. Adınızı yazın, haritanızı seçin ve konuşlanın.
      </p>

      <div className="w-full max-w-sm mt-8 flex flex-col gap-6">
        <div className="flex flex-col items-start">
          <label className="text-slate-400 text-sm font-bold mb-2 uppercase tracking-wider" htmlFor="playerName">
            Oyuncu Adı
          </label>
          <input
            id="playerName"
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            placeholder="En az 3 karakter"
            maxLength={16}
            className="w-full px-4 py-3 bg-slate-900/50 border-2 border-slate-700 rounded-lg text-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
          />
        </div>

        <div className="flex flex-col items-start">
          <label className="text-slate-400 text-sm font-bold mb-2 uppercase tracking-wider">
            Harita Seç
          </label>
          <div className="grid grid-cols-3 gap-3 w-full">
            {MAPS.map((map) => (
              <button
                key={map.id}
                onClick={() => setSelectedMapId(map.id)}
                className={`p-3 rounded-lg border-2 transition ${
                  selectedMapId === map.id ? 'bg-cyan-500/20 border-cyan-500' : 'bg-slate-900/50 border-slate-700 hover:border-slate-500'
                }`}
              >
                <div className="aspect-square w-full bg-slate-800 rounded relative overflow-hidden">
                  {map.obstacles.map((obs, i) => (
                     <div key={i} className="absolute bg-slate-600" style={{ left: `${obs.x}%`, top: `${obs.y}%`, width: `${obs.width}%`, height: `${obs.height}%`}}></div>
                  ))}
                </div>
                <span className="block text-slate-200 text-sm mt-2 font-semibold">{map.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <button
        onClick={() => onStart(playerName, selectedMapId)}
        disabled={isDeployDisabled}
        className="mt-8 px-10 py-4 bg-cyan-500 text-slate-900 font-bold text-xl uppercase tracking-wider rounded-lg shadow-lg shadow-cyan-500/30 transform hover:scale-105 hover:bg-cyan-400 transition-all duration-300 disabled:bg-slate-600 disabled:text-slate-400 disabled:cursor-not-allowed disabled:scale-100 disabled:shadow-none"
      >
        Deploy
      </button>
    </div>
  );
};

export default StartScreen;