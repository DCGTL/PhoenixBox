import { MapData } from "./types";

export const GAME_DURATION_SECONDS = 60;
export const PLAYER_SPAWN_INTERVAL_MS = 1200;
export const LOOT_SPAWN_INTERVAL_MS = 8000;

export const MIN_PLAYER_SIZE = 40;
export const MAX_PLAYER_SIZE = 60;
export const LOOT_CRATE_SIZE = 35;


export const MAPS: MapData[] = [
  {
    id: 1,
    name: "Açık Arena",
    obstacles: [],
  },
  {
    id: 2,
    name: "Merkez Blok",
    obstacles: [
      { x: 40, y: 40, width: 20, height: 20 },
    ],
  },
  {
    id: 3,
    name: "Sütunlar",
    obstacles: [
      { x: 25, y: 20, width: 10, height: 60 },
      { x: 65, y: 20, width: 10, height: 60 },
    ],
  },
];