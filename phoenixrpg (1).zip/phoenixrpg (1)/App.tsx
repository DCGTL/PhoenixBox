import React, { useState, useCallback } from 'react';
import GameScreen from './components/GameScreen';
import StartScreen from './components/StartScreen';
import GameOverScreen from './components/GameOverScreen';
import { GameState } from './types';
import { MAPS } from './constants';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.Ready);
  const [score, setScore] = useState(0);
  const [playerName, setPlayerName] = useState('');
  const [mapId, setMapId] = useState(MAPS[0].id);

  const startGame = useCallback((name: string, selectedMapId: number) => {
    setPlayerName(name);
    setMapId(selectedMapId);
    setScore(0);
    setGameState(GameState.Playing);
  }, []);

  const endGame = useCallback((finalScore: number) => {
    setScore(finalScore);
    setGameState(GameState.GameOver);
  }, []);

  const backToMenu = useCallback(() => {
    setGameState(GameState.Ready);
  }, []);

  const renderGameState = () => {
    switch (gameState) {
      case GameState.Playing:
        return <GameScreen onGameOver={endGame} playerName={playerName} mapId={mapId} />;
      case GameState.GameOver:
        return <GameOverScreen score={score} onRestart={backToMenu} playerName={playerName} />;
      case GameState.Ready:
      default:
        return <StartScreen onStart={startGame} />;
    }
  };

  return (
    <main className="bg-black text-white w-screen h-screen flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))]"></div>
      <div className="z-10 w-full h-full flex flex-col items-center justify-center">
        {renderGameState()}
      </div>
    </main>
  );
};

export default App;