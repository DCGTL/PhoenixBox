export enum GameState {
  Ready,
  Playing,
  GameOver,
}

export interface Player {
  id: number;
  x: number;
  y: number;
  size: number;
  // For movement
  vx: number; 
  vy: number;
}

export interface LootCrate {
  id: number;
  x: number;
  y: number;
  size: number;
  type: 'score' | 'time';
}

export interface Obstacle {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface MapData {
  id: number;
  name: string;
  obstacles: Obstacle[];
}